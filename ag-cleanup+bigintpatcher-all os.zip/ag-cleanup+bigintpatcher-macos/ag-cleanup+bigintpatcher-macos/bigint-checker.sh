﻿#!/bin/bash

# =====================================================================================
#  Antigravity BigInt Checker for macOS
# =====================================================================================

# --- Config ---
TARGET_FILE="$HOME/Library/Application Support/Antigravity/app/out/main.js"
LOG_FILE="$(dirname "$0")/bigint-scan.log"

# --- Colors ---
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
GRAY='\033[0;90m'
NC='\033[0m' # No Color

# --- Utility Functions ---
write_header() {
    clear
    echo -e ""
    echo -e "${CYAN}  ==============================================================${NC}"
    echo -e "${CYAN}             $1${NC}"
    echo -e "${CYAN}  ==============================================================${NC}"
    echo -e ""
}

# This is the core classification logic, translated from PowerShell.
# It uses perl for robust regex matching.
get_classification() {
    local text="$1"
    # Extract arguments from JSON.stringify(arguments)
    local args_content=$(echo "$text" | perl -nE 'say $1 if /^JSON\.stringify\((.*)\)$/')

    # Check if arguments contain characters that make it complex (risky)
    if echo "$args_content" | grep -q -P '[\{\(\[\]\}\,]'; then
        echo "risky"
    else
        echo "easy"
    fi
}

# --- Main Application Loop ---
if [[ ! -f "$TARGET_FILE" ]]; then
    write_header "Error"
    echo -e "  ${RED}Antigravity main.js not found at $TARGET_FILE${NC}"
    exit 1
fi

while true; do
    write_header "macOS BigInt Checker"
    
    # --- Analysis Phase ---
    # Use perl to find all instances of JSON.stringify(...), handling nested parentheses.
    mapfile -t all_found_matches < <(perl -0777 -nE 'say for /JSON\.stringify\((?:[^()]|\([^()]*\))*\)/g' "$TARGET_FILE")

    # Process matches to classify them
    all_items=()
    patched_easy_count=0
    patched_risky_added_count=0
    patched_risky_wrapped_count=0
    unpatched_easy_count=0
    unpatched_risky_count=0

    for text in "${all_found_matches[@]}"; do
        item_type=""
        item_color="$GRAY"

        if [[ "$text" == *"typeof _r ==="*"bigint"* ]]; then
            item_type="Patched (Risky-Wrapped)"
            item_color="$CYAN"
            ((patched_risky_wrapped_count++))
        elif [[ "$text" == *"(_k, v) => typeof v === \"bigint\""* ]]; then
            unpatched_version=$(echo "$text" | perl -pe 's/,\s*\(_k, v\) => typeof v === "bigint" \? v\.toString\(\) : v//g')
            classification=$(get_classification "$unpatched_version")
            if [[ "$classification" == "easy" ]]; then
                item_type="Patched (Easy)"
                item_color="$GREEN"
                ((patched_easy_count++))
            else
                item_type="Patched (Risky-Added)"
                item_color="$YELLOW"
                ((patched_risky_added_count++))
            fi
        else
            classification=$(get_classification "$text")
            if [[ "$classification" == "easy" ]]; then
                item_type="Unpatched (Easy)"
                item_color="$RED"
                ((unpatched_easy_count++))
            else
                item_type="Unpatched (Risky)"
                item_color="$YELLOW"
                ((unpatched_risky_count++))
            fi
        fi
        all_items+=("$(echo -e "${item_color}${text}${NC}")___${item_type}") # Store with color and type
    done

    # --- UI & Menu ---
    echo -e "  ${GREEN}Scan Complete!${NC}"
    echo -e "  - ${GREEN}Patched (Easy):          $patched_easy_count${NC}"
    echo -e "  - ${YELLOW}Patched (Risky-Added):   $patched_risky_added_count${NC}"
    echo -e "  - ${CYAN}Patched (Risky-Wrapped): $patched_risky_wrapped_count${NC}"
    echo -e "  - ${RED}Unpatched (Easy):        $unpatched_easy_count${NC}"
    echo -e "  - ${YELLOW}Unpatched (Risky):       $unpatched_risky_count${NC}"
    echo -e ""
    
    echo -e "  ${GRAY}OPTIONS:${NC}"
    echo -e "  1. Show All items"
    echo -e "  2. Show Patched items"
    echo -e "  3. Show Unpatched items"
    echo -e "  4. Save log and Exit"
    read -p "  Enter Option#: " choice

    case "$choice" in
        1)
            write_header "All JSON.stringify Calls (${#all_items[@]})"
            for item in "${all_items[@]}"; do
                text_part=$(echo "$item" | cut -d'_' -f1)
                echo -e "  $text_part"
            done
            read -p $ '\n  Press Enter to return to menu'
            ;;
        2)
            total_patched=$(($patched_easy_count + $patched_risky_added_count + $patched_risky_wrapped_count))
            write_header "Patched Calls ($total_patched)"
            for item in "${all_items[@]}"; do
                type_part=$(echo "$item" | cut -d'_' -f4)
                if [[ "$type_part" == Patched* ]]; then
                     text_part=$(echo "$item" | cut -d'_' -f1)
                     echo -e "  $text_part"
                fi
            done
            read -p $'\n  Press Enter to return to menu'
            ;;
        3)
            total_unpatched=$(($unpatched_easy_count + $unpatched_risky_count))
            write_header "Unpatched Calls ($total_unpatched)"
            for item in "${all_items[@]}"; do
                type_part=$(echo "$item" | cut -d'_' -f4)
                if [[ "$type_part" == Unpatched* ]]; then
                     text_part=$(echo "$item" | cut -d'_' -f1)
                     echo -e "  $text_part"
                fi
            done
            read -p $'\n  Press Enter to return to menu'
            ;;
        4)
            echo "Antigravity BigInt Scan Results" > "$LOG_FILE"
            echo "=================================================" >> "$LOG_FILE"
            echo "Scan Date: $(date)" >> "$LOG_FILE"
            echo "Target File: $TARGET_FILE" >> "$LOG_FILE"
            echo "" >> "$LOG_FILE"
            echo "Summary:" >> "$LOG_FILE"
            echo "- Patched (Easy):          $patched_easy_count" >> "$LOG_FILE"
            echo "- Patched (Risky-Added):   $patched_risky_added_count" >> "$LOG_FILE"
            echo "- Patched (Risky-Wrapped): $patched_risky_wrapped_count" >> "$LOG_FILE"
            echo "- Unpatched (Easy):        $unpatched_easy_count" >> "$LOG_FILE"
            echo "- Unpatched (Risky):       $unpatched_risky_count" >> "$LOG_FILE"
            echo "" >> "$LOG_FILE"
            echo "Details:" >> "$LOG_FILE"
            echo "=================================================" >> "$LOG_FILE"
            for item in "${all_items[@]}"; do
                text_part=$(echo "$item" | perl -pe 's/\x1b\[[0-9;]*[mG]//g' | cut -d'_' -f1)
                type_part=$(echo "$item" | cut -d'_' -f4)
                 echo "[$type_part] - $text_part" >> "$LOG_FILE"
            done
            echo -e "\n  ${GREEN}Log saved to $LOG_FILE${NC}"
            sleep 2
            exit 0
            ;;
    esac
done