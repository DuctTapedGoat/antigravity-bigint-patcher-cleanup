#!/bin/bash

# =====================================================================================
#  Antigravity BigInt Patcher for macOS
# =====================================================================================

# --- Config ---
TARGET_FILE="$HOME/Library/Application Support/Antigravity/app/out/main.js"
BACKUP_FILE="${TARGET_FILE}.bak"
PATCHED_LOGIC='(_k, v) => typeof v === "bigint" ? v.toString() : v'

# --- Colors ---
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
GRAY='\033[0;90m'
NC='\033[0m' # No Color

# --- Utility Functions ---
write_header() {
    clear
    echo -e ""
    echo -e "${CYAN}  ==============================================================${NC}"
    echo -e "${CYAN}             $1${NC}"
    echo -e "${CYAN}  ==============================================================${NC}"
    echo -e ""
}

get_classification() {
    local text="$1"
    local args_content=$(echo "$text" | perl -nE 'say $1 if /^JSON\.stringify\((.*)\)$/')
    if echo "$args_content" | grep -q -P '[\{\(\[\]\}\,]'; then
        echo "risky"
    else
        echo "easy"
    fi
}

# --- Main Application Loop ---
if [[ ! -f "$TARGET_FILE" ]]; then
    write_header "Error"
    echo -e "  ${RED}Antigravity main.js not found at $TARGET_FILE${NC}"
    exit 1
fi

while true; do
    write_header "macOS BigInt Omni-Patcher"
    
    # --- Analysis Phase ---
    # Use Perl to get all matches and their starting positions.
    mapfile -t all_found_matches_with_pos < <(perl -0777 -nE 'while (/JSON\.stringify\((?:[^()]|\([^()]*\))*\)/g) { say $& . "@@" . (pos() - length($&)) }' "$TARGET_FILE")

    patched_easy_count=0
    patched_risky_added_count=0
    patched_risky_wrapped_count=0
    unpatched_easy_count=0
    unpatched_risky_count=0
    unpatched_easy_items=()
    unpatched_risky_items=()

    for item_with_pos in "${all_found_matches_with_pos[@]}"; do
        text="${item_with_pos%@@*}"
        match_pos="${item_with_pos#*@@}"

        if [[ "$text" == *"typeof _r ==="*"bigint"* ]]; then
            ((patched_risky_wrapped_count++))
        elif [[ "$text" == *"$PATCHED_LOGIC"* ]]; then
            unpatched_version=$(echo "$text" | perl -pe "s/,\s*\Q$PATCHED_LOGIC\E//g")
            classification=$(get_classification "$unpatched_version")
            if [[ "$classification" == "easy" ]]; then
                ((patched_easy_count++))
            else
                ((patched_risky_added_count++))
            fi
        else
            classification=$(get_classification "$text")
            if [[ "$classification" == "easy" ]]; then
                unpatched_easy_items+=("$match_pos@@$text")
                ((unpatched_easy_count++))
            else
                unpatched_risky_items+=("$match_pos@@$text")
                ((unpatched_risky_count++))
            fi
        fi
    done

    # --- UI & Menu ---
    echo -e "  ${GREEN}Scan Complete!${NC}"
    echo -e "  - ${GREEN}Patched (Easy):          $patched_easy_count${NC}"
    echo -e "  - ${YELLOW}Patched (Risky-Added):   $patched_risky_added_count${NC}"
    echo -e "  - ${CYAN}Patched (Risky-Wrapped): $patched_risky_wrapped_count${NC}"
    echo -e "  - ${RED}Unpatched (Easy):        $unpatched_easy_count${NC}"
    echo -e "  - ${YELLOW}Unpatched (Risky):       $unpatched_risky_count${NC}"
    echo -e ""
    
    echo -e "  ${GRAY}OPTIONS:${NC}"
    echo -e "  1. Bulk Patch all EASY ($unpatched_easy_count)"
    echo -e "  2. Bulk Patch all RISKY ($unpatched_risky_count)"
    echo -e "  3. Exit"
    echo -e ""
    read -p "  Enter Option#: " choice

    if [[ "$choice" == "3" ]]; then exit 0; fi

    if [[ ! -f "$BACKUP_FILE" ]]; then
        echo -e "  ${YELLOW}Creating backup of fresh install...${NC}"
        cp "$TARGET_FILE" "$BACKUP_FILE"
    fi

    current_content=$(<"$TARGET_FILE")

    if [[ "$choice" == "1" ]]; then
        if [[ $unpatched_easy_count -eq 0 ]]; then echo "  No easy patches available."; sleep 1; continue; fi
        echo -e "  ${YELLOW}Applying easy patches...${NC}"

        IFS=$ '\n' sorted_easy=($(sort -t '@' -k1 -nr <<<"${unpatched_easy_items[*]}"))
        unset IFS

        for item in "${sorted_easy[@]}"; do
            pos_to_patch="${item%@@*}"
            text_to_patch="${item#*@@}"
            args_content=$(echo "$text_to_patch" | perl -nE 'say $1 if /^JSON\.stringify\((.*)\)$/')
            replacement="JSON.stringify($args_content, $PATCHED_LOGIC)"
            current_content=$(perl -0777 -pe 'my ($pos, $old_len, $new) = @ARGV; substr($_, $pos, $old_len) = $new;' -- "$pos_to_patch" "${#text_to_patch}" "$replacement" <<< "$current_content")
        done
        echo -n "$current_content" > "$TARGET_FILE"
        echo -e "  ${GREEN}Easy Bulk Patch Applied!${NC}"; sleep 2
    fi

    if [[ "$choice" == "2" ]]; then
        if [[ $unpatched_risky_count -eq 0 ]]; then echo "  No risky patches available."; sleep 1; continue; fi

        pos_sum=0
        for item in "${unpatched_risky_items[@]}"; do
            pos="${item%@@*}"
            pos_sum=$(($pos_sum + $pos))
        done
        line_sum=$(($pos_sum / 1000)) 
        security_key="${line_sum}:${pos_sum}"

        echo -e ""
        echo -e "  ${YELLOW}DANGEROUS: To confirm this risky patch, type the following key and press Enter:${NC}"
        echo -e "  ${CYAN}$security_key${NC}"
        read -p "  Enter security key: " user_input

        if [[ "$user_input" != "$security_key" ]]; then echo -e "  ${RED}Incorrect key.${NC}"; sleep 2; continue; fi
        
        echo -e "  ${YELLOW}Applying risky patches...${NC}"
        
        IFS=$ '\n' sorted_risky=($(sort -t '@' -k1 -nr <<<"${unpatched_risky_items[*]}"))
        unset IFS
        
        for item in "${sorted_risky[@]}"; do
            pos_to_patch="${item%@@*}"
            text_to_patch="${item#*@@}"
            args_content=$(echo "$text_to_patch" | perl -nE 'say $1 if /^JSON\.stringify\((.*)\)$/')
            
            is_single_arg="true"
            if echo "$args_content" | grep -q -P '[\{\(\[\]\}]\s*,.+'; then
                is_single_arg="false"
            fi
            
            replacement=""
            if [[ "$is_single_arg" == "true" ]]; then
                replacement="JSON.stringify($args_content, $PATCHED_LOGIC)"
            else
                replacement=$(perl -e '
                    my $args = shift;
                    my $patched_logic = q('"$PATCHED_LOGIC"');
                    my ($depth, $in_string, $first_comm-index) = (0, 0, -1);
                    my ($string_char, $is_escaped) = ("", 0);
                    my @chars = split //, $args;
                    for (my $i=0; $i < @chars; $i++) {
                        my $char = $chars[$i];
                        if ($is_escaped) { $is_escaped = 0; next; }
                        if ($char eq "\\") { $is_escaped = 1; next; }
                        if ($char eq "\'" or $char eq "\"" or $char eq "`") {
                            if ($in_string and $char eq $string_char) { $in_string = 0; } elsif (not $in_string) { $in_string = 1; $string_char = $char; }
                        }
                        if ($in_string) { next; }
                        if ($char eq "(" or $char eq "{" or $char eq "[") { $depth++; }
                        elsif ($char eq ")" or $char eq "}" or $char eq "]") { $depth--; }
                        if ($char eq "," and $depth == 0) { $first_comm-index = $i; last; }
                    }

                    if ($first_comm-index != -1) {
                        my $arg1 = substr($args, 0, $first_comm-index);
                        my $rest = substr($args, $first_comm-index + 1);
                        $arg1 =~ s/^\s+|\s+$//g;
                        $rest =~ s/^\s+|\s+$//g;
                        my $replacer = $rest;
                        my $rest_of_args = "";
                        ($depth, $in_string, $string_char, $is_escaped) = (0, 0, "", 0);
                        my $second_comm-index = -1;
                        @chars = split //, $rest;
                        for (my $i=0; $i < @chars; $i++) {
                             my $char = $chars[$i];
                             if ($is_escaped) { $is_escaped = 0; next; }
                             if ($char eq "\\") { $is_escaped = 1; next; }
                             if ($char eq "\'" or $char eq "\"" or $char eq "`") {
                                if ($in_string and $char eq $string_char) { $in_string = 0; } elsif (not $in_string) { $in_string = 1; $string_char = $char; }
                             }
                             if ($in_string) { continue; }
                             if ($char eq "(" or $char eq "{" or $char eq "[") { $depth++; }
                             elseif ($char eq ")" or $char eq "}" or $char eq "]") { $depth--; }
                             if ($char eq "," and $depth == 0) { $second_comm-index = $i; last; }
                        }

                        if ($second_comm-index != -1) {
                            $replacer = substr($rest, 0, $second_comm-index);
                            $replacer =~ s/^\s+|\s+$//g;
                            $rest_of_args = substr($rest, $second_comm-index);
                        }

                        my $wrapped_replacer = "(_k, v) => { let _r = ($replacer)(_k, v); return typeof _r === `bigint` ? _r.toString() : _r; }";
                        print "JSON.stringify($arg1, $wrapped_replacer$rest_of_args)";
                    } else {
                        print "JSON.stringify($args, $patched_logic)";
                    }
                ' "$args_content")
            fi
            current_content=$(perl -0777 -pe 'my ($pos, $old_len, $new) = @ARGV; substr($_, $pos, $old_len) = $new;' -- "$pos_to_patch" "${#text_to_patch}" "$replacement" <<< "$current_content")
        done

        echo -n "$current_content" > "$TARGET_FILE"
        echo -e "  ${GREEN}Risky Bulk Patch Applied!${NC}"; sleep 2
    fi
done