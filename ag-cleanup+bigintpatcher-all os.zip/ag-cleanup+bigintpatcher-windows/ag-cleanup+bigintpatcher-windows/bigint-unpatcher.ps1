# =====================================================================================
#  Antigravity BigInt Unpatcher for Windows
# =====================================================================================

$targetFile = Join-Path $env:LOCALAPPDATA 'Programs\Antigravity\resources\app\out\main.js'
$backupFile = "$targetFile.bak"
$patchedBackupFile = "$targetFile.patched.bak" # A backup of the patched file, if one exists
$easyPatchLogic = '(_k, v) => typeof v === "bigint" ? v.toString() : v'

# --- Regex for UNPATCHING ---
# This will find an easy patch and capture the single argument before it.
$easyUnpatchRegex = 'JSON\.stringify\(([^,]*?),\s*' + [regex]::escape($easyPatchLogic) + '\)'

# This will find a risky patch where we wrapped a replacer, and extract the original three parts.
$riskyWrappedUnpatchRegex = 'JSON\.stringify\((.*?),\s*\(_k, v\)\s*=>\s*{\s*let\s*_r\s*=\s*\((.*?)\)\(_k, v\);\s*return\s*typeof\s*_r\s*===\s*"bigint"\s*\?\s*_r\.toString\(\)\s*:\s*_r;\s*}(,.*?)?\)'

# This will find a risky patch where we ADDED a replacer to a complex single argument.
$riskyAddedUnpatchRegex = 'JSON\.stringify\(([\{\(\[].*?[\}\)\]]),\s*' + [regex]::escape($easyPatchLogic) + '\)'

# --- Utility Functions ---
function Write-Header($title) {
    Clear-Host
    Write-Host ""
    Write-Host "  ==============================================================" -ForegroundColor Cyan
    Write-Host "             $title" -ForegroundColor Cyan
    Write-Host "  ==============================================================" -ForegroundColor Cyan
    Write-Host ""
}

# --- Main Application Loop ---
if (-not (Test-Path $targetFile)) { Write-Header "Error"; Write-Host "  Antigravity main.js not found at $targetFile" -ForegroundColor Red; exit }

while ($true) {
    Write-Header "Windows BigInt Omni-Unpatcher"
    $content = Get-Content -Raw $targetFile

    # --- Analysis Phase ---
    $allRegex = 'JSON\.stringify\((?:[^()]|\([^()]*\))*\)'
    $allFoundMatches = [regex]::Matches($content, $allRegex)
    $allItems = @()
    $lineNumber = 1
    $currentPos = 0

    # This classification function must be IDENTICAL to the one in the patcher and checker.
    function Get-Classification {
        param($text)
        if ($text -notmatch '^JSON\.stringify\((.*)\)$') { return @{ Type = 'unknown' } }
        $argsContent = $Matches[1].Trim()
        if ($argsContent -match '[\{\(\[\]\}\,]') { return @{ Type = 'risky' } } else { return @{ Type = 'easy' } }
    }

    foreach ($m in $allFoundMatches) {
        $text = $m.Value
        $index = $m.Index
        $gap = $content.Substring($currentPos, $index - $currentPos)
        $lineNumber += ($gap -split "`n").Length - 1
        $currentPos = $index
        
        $item = [PSCustomObject]@{ Line = $lineNumber; Position = $index; Text = $text; Type = ''; Color = 'Gray' }

        if ($text -like '*(typeof _r ===*bigint*)*') { # Check for the most specific patch first (Risky-Wrapped)
            $item.Type = 'Patched (Risky-Wrapped)'; $item.Color = 'Cyan'
        } elseif ($text -like 'JSON.stringify(*, (_k, v) => typeof v === "bigint"*') { # Easy or Risky-Added
            $unpatchedVersion = $text -replace ',\s*\(_k, v\) => typeof v === "bigint" \? v\.toString\(\) : v', ''
            $classification = Get-Classification -text $unpatchedVersion
            if ($classification.Type -eq 'easy') {
                $item.Type = 'Patched (Easy)'; $item.Color = 'Green'
            } else {
                $item.Type = 'Patched (Risky-Added)'; $item.Color = 'Yellow'
            }
        } else { # Unpatched
            $classification = Get-Classification -text $text
            if ($classification.Type -eq 'easy') {
                $item.Type = 'Unpatched (Easy)'; $item.Color = 'Red'
            } else {
                $item.Type = 'Unpatched (Risky)'; $item.Color = 'Yellow'
            }
        }
        $allItems += $item
    }

    # --- Count Categories ---
    $patchedEasyCount = ($allItems | Where-Object { $_.Type -eq 'Patched (Easy)' }).Count
    $patchedRiskyAddedCount = ($allItems | Where-Object { $_.Type -eq 'Patched (Risky-Added)' }).Count
    $patchedRiskyWrappedCount = ($allItems | Where-Object { $_.Type -eq 'Patched (Risky-Wrapped)' }).Count
    $unpatchedEasyCount = ($allItems | Where-Object { $_.Type -eq 'Unpatched (Easy)' }).Count
    $unpatchedRiskyCount = ($allItems | Where-Object { $_.Type -eq 'Unpatched (Risky)' }).Count
    $totalPatchedCount = $patchedEasyCount + $patchedRiskyAddedCount + $patchedRiskyWrappedCount

    # --- UI & Menu ---
    Write-Host "  File Scan Results:"
    Write-Host "  - Patched (Easy):          $patchedEasyCount" -ForegroundColor Green
    Write-Host "  - Patched (Risky-Added):   $patchedRiskyAddedCount" -ForegroundColor Yellow
    Write-Host "  - Patched (Risky-Wrapped): $patchedRiskyWrappedCount" -ForegroundColor Cyan
    Write-Host "  - Unpatched (Easy):        $unpatchedEasyCount" -ForegroundColor Red
    Write-Host "  - Unpatched (Risky):       $unpatchedRiskyCount" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  OPTIONS:" -ForegroundColor Gray
    Write-Host "  1. Unpatch ALL ($totalPatchedCount found)"
    Write-Host "  2. Unpatch Easy only ($patchedEasyCount found)"
    Write-Host "  3. Unpatch Risky-Added only ($patchedRiskyAddedCount found)"
    Write-Host "  4. Unpatch Risky-Wrapped only ($patchedRiskyWrappedCount found)"
    Write-Host "  5. Restore from backup ($backupFile)"
    Write-Host "  6. Exit"
    $choice = Read-Host "  Enter Option#"

    switch ($choice) {
        '1' { # UNPATCH ALL
            if ($totalPatchedCount -eq 0) { Write-Host "  No patches to remove."; Start-Sleep 1; continue }
            Write-Host "  Unpatching all found patches..." -ForegroundColor Yellow
            if (-not (Test-Path $patchedBackupFile)) { Copy-Item $targetFile $patchedBackupFile -Force -Encoding UTF8 }

            $newContent = $content
            # Order matters: Go from most specific to least specific regex.
            $newContent = $newContent -replace $riskyWrappedUnpatchRegex, 'JSON.stringify($1, $2$3)' 
            $newContent = $newContent -replace $riskyAddedUnpatchRegex, 'JSON.stringify($1)'
            $newContent = $newContent -replace $easyUnpatchRegex, 'JSON.stringify($1)'

            Set-Content -Path $targetFile -Value $newContent -NoNewline -Encoding UTF8
            Write-Host "  Bulk Unpatch Applied!" -ForegroundColor Green; Start-Sleep 2
        }
        '2' { # UNPATCH EASY
            if ($patchedEasyCount -eq 0) { Write-Host "  No easy patches to remove."; Start-Sleep 1; continue }
            if (-not (Test-Path $patchedBackupFile)) { Copy-Item $targetFile $patchedBackupFile -Force -Encoding UTF8 }
            $newContent = $content -replace $easyUnpatchRegex, 'JSON.stringify($1)'
            Set-Content -Path $targetFile -Value $newContent -NoNewline -Encoding UTF8
            Write-Host "  Easy patches removed!" -ForegroundColor Green; Start-Sleep 2
        }
        '3' { # UNPATCH RISKY-ADDED
            if ($patchedRiskyAddedCount -eq 0) { Write-Host "  No risky-added patches to remove."; Start-Sleep 1; continue }
            if (-not (Test-Path $patchedBackupFile)) { Copy-Item $targetFile $patchedBackupFile -Force -Encoding UTF8 }
            $newContent = $content -replace $riskyAddedUnpatchRegex, 'JSON.stringify($1)'
            Set-Content -Path $targetFile -Value $newContent -NoNewline -Encoding UTF8
            Write-Host "  Risky-added patches removed!" -ForegroundColor Green; Start-Sleep 2
        }
        '4' { # UNPATCH RISKY-WRAPPED
            if ($patchedRiskyWrappedCount -eq 0) { Write-Host "  No risky-wrapped patches to remove."; Start-Sleep 1; continue }
            if (-not (Test-Path $patchedBackupFile)) { Copy-Item $targetFile $patchedBackupFile -Force -Encoding UTF8 }
            $newContent = $content -replace $riskyWrappedUnpatchRegex, 'JSON.stringify($1, $2$3)'
            Set-Content -Path $targetFile -Value $newContent -NoNewline -Encoding UTF8
            Write-Host "  Risky-wrapped patches removed!" -ForegroundColor Green; Start-Sleep 2
        }
        '5' { # RESTORE BACKUP
            if (Test-Path $backupFile) {
                Write-Host "  Restoring original file from $backupFile..." -ForegroundColor Yellow
                Copy-Item $backupFile $targetFile -Force
                (Get-Content $targetFile -Raw) | Set-Content -Path $targetFile -NoNewline -Encoding utf8 # Ensure encoding is correct after restore
                Write-Host "  Restore complete!" -ForegroundColor Green
            } else {
                Write-Host "  Backup file not found ($backupFile)." -ForegroundColor Red
            }
            Start-Sleep 2
        }
        '6' { exit }
    }
}
