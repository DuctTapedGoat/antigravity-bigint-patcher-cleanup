
# =====================================================================================
#  Antigravity BigInt Patcher for Windows
# =====================================================================================

$targetFile = Join-Path $env:LOCALAPPDATA 'Programs\Antigravity\resources\app\out\main.js'
$backupFile = "$targetFile.bak"
$patchedLogic = '(_k, v) => typeof v === "bigint" ? v.toString() : v'

# --- Utility Functions ---

function Write-Header($title) {
    Clear-Host
    Write-Host ""
    Write-Host "  ==============================================================" -ForegroundColor Cyan
    Write-Host "             $title" -ForegroundColor Cyan
    Write-Host "  ==============================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Get-Classification {
    param($text)

    if ($text -notmatch '^JSON\.stringify\((.*)\)$') { return @{ Type = 'unknown' } }
    $argsContent = $Matches[1].Trim()

    # If it contains any of these characters, it's not a simple variable, so it's risky.
    if ($argsContent -match '[\{\(\[\]\}\,]') {
        return @{ Type = 'risky' }
    } else {
        return @{ Type = 'easy' }
    }
}


# --- Main Application Loop ---

if (-not (Test-Path $targetFile)) {
    Write-Header "Error"
    Write-Host "  Antigravity main.js not found at $targetFile" -ForegroundColor Red
    exit
}

$content = Get-Content -Raw $targetFile

while ($true) {
    Write-Header "Windows BigInt Omni-Patcher v8 (Final)"

    # --- Analysis Phase ---
    # This section is now IDENTICAL to the checker and unpatcher for unified logic.
    $allRegex = 'JSON\.stringify\((?:[^()]|\([^()]*\))*\)'
    $allFoundMatches = [regex]::Matches($content, $allRegex)
    $allItems = @()
    $lineNumber = 1
    $currentPos = 0

    foreach ($m in $allFoundMatches) {
        $text = $m.Value
        $index = $m.Index
        $gap = $content.Substring($currentPos, $index - $currentPos)
        $lineNumber += ($gap -split "`n").Length - 1
        $currentPos = $index
        
        $item = [PSCustomObject]@{ Line = $lineNumber; Position = $index; Text = $text; Type = ''; Color = 'Gray' }

        if ($text -like '*(typeof _r ===*bigint*)*') { # Check for the most specific patch first (Risky-Wrapped)
            $item.Type = 'Patched (Risky-Wrapped)'; $item.Color = 'Cyan'
        } elseif ($text -like 'JSON.stringify(*, (_k, v) => typeof v === "bigint"*') { # Easy or Risky-Added
            $unpatchedVersion = $text -replace ',\s*\(_k, v\) => typeof v === "bigint" \? v\.toString\(\) : v', ''
            $classification = Get-Classification -text $unpatchedVersion
            if ($classification.Type -eq 'easy') {
                $item.Type = 'Patched (Easy)'; $item.Color = 'Green'
            } else {
                $item.Type = 'Patched (Risky-Added)'; $item.Color = 'Yellow'
            }
        } else { # Unpatched
            $classification = Get-Classification -text $text
            if ($classification.Type -eq 'easy') {
                $item.Type = 'Unpatched (Easy)'; $item.Color = 'Red'
            } else {
                $item.Type = 'Unpatched (Risky)'; $item.Color = 'Yellow'
            }
        }
        $allItems += $item
    }

    # --- Count Categories ---
    $patchedEasyCount = ($allItems | Where-Object { $_.Type -eq 'Patched (Easy)' }).Count
    $patchedRiskyAddedCount = ($allItems | Where-Object { $_.Type -eq 'Patched (Risky-Added)' }).Count
    $patchedRiskyWrappedCount = ($allItems | Where-Object { $_.Type -eq 'Patched (Risky-Wrapped)' }).Count
    $unpatchedEasyCount = ($allItems | Where-Object { $_.Type -eq 'Unpatched (Easy)' }).Count
    $unpatchedRiskyCount = ($allItems | Where-Object { $_.Type -eq 'Unpatched (Risky)' }).Count

    Write-Host "  Scan Complete!"
    Write-Host "  - Patched (Easy):          $patchedEasyCount" -ForegroundColor Green
    Write-Host "  - Patched (Risky-Added):   $patchedRiskyAddedCount" -ForegroundColor Yellow
    Write-Host "  - Patched (Risky-Wrapped): $patchedRiskyWrappedCount" -ForegroundColor Cyan
    Write-Host "  - Unpatched (Easy):        $unpatchedEasyCount" -ForegroundColor Red
    Write-Host "  - Unpatched (Risky):       $unpatchedRiskyCount" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  OPTIONS:" -ForegroundColor Gray
    Write-Host "  1. Bulk Patch all EASY ($unpatchedEasyCount)"
    Write-Host "  2. Bulk Patch all RISKY ($unpatchedRiskyCount)" -ForegroundColor Yellow
    Write-Host "  3. Exit"
    Write-Host ""

    $choice = Read-Host "  Enter Option#"

    if ($choice -eq "3") { exit }

    if (-not (Test-Path $backupFile)) {
        Write-Host "  Creating backup of fresh install..." -ForegroundColor Yellow
        Copy-Item $targetFile $backupFile -Force
    }

    $patcherRegex = '^JSON\.stringify\((.*)\)$';

    if ($choice -eq "1") {
        if ($unpatchedEasyCount -eq 0) { Write-Host "  No easy patches available."; Start-Sleep 1; continue }
        $newContent = $content
        $sortedEasy = $allItems | Where-Object { $_.Type -eq 'Unpatched (Easy)' } | Sort-Object Position -Descending

        foreach ($h in $sortedEasy) {
            if ($h.Text -match $patcherRegex) {
                $argsContent = $Matches[1]
                $replacement = "JSON.stringify($argsContent, $patchedLogic)"
                $newContent = $newContent.Remove($h.Position, $h.Text.Length).Insert($h.Position, $replacement)
            }
        }
        $content = $newContent
        Set-Content -Path $targetFile -Value $content -NoNewline -Encoding UTF8
        Write-Host "  Easy Bulk Patch Applied!" -ForegroundColor Green; Start-Sleep 2
    }

    if ($choice -eq "2") {
        if ($unpatchedRiskyCount -eq 0) { Write-Host "  No risky patches available."; Start-Sleep 1; continue }
        $riskyHits = $allItems | Where-Object { $_.Type -eq 'Unpatched (Risky)' }
        $lineSum = ($riskyHits | Measure-Object -Property Line -Sum).Sum
        $indexSum = ($riskyHits | Measure-Object -Property Position -Sum).Sum
        $securityKey = "${lineSum}:${indexSum}"

        Write-Host ""
        Write-Host "  DANGEROUS: To confirm this risky patch, type the following key and press Enter:" -ForegroundColor Yellow
        Write-Host "  $securityKey" -ForegroundColor Cyan
        $userInput = Read-Host "  Enter security key"

        if ($userInput -ne $securityKey) { Write-Host "  Incorrect key."; Start-Sleep 2; continue }

        $newContent = $content
        $sortedRisky = $riskyHits | Sort-Object Position -Descending

        foreach ($h in $sortedRisky) {
             if ($h.Text -match $patcherRegex) {
                $argsContent = $Matches[1]

                # Determine if this is a single-arg or multi-arg risky call
                $isSingleArg = $true
                if ($argsContent -match '[\{\(\[\]\}]\s*,.+') {
                    $isSingleArg = $false
                }

                if ($isSingleArg) {
                    # It's a single, complex argument. Add our replacer.
                    $newText = "JSON.stringify($argsContent, $patchedLogic)"
                    $newContent = $newContent.Remove($h.Position, $h.Text.Length).Insert($h.Position, $newText)
                } else {
                    # It's a multi-argument call. Wrap the existing replacer.
                    $depth = 0; $inString = $false; $stringChar = ''; $isEscaped = $false; ${first_comm-index} = -1
                    for ($i = 0; $i -lt $argsContent.Length; $i++) {
                        $char = $argsContent[$i]
                        if ($isEscaped) { $isEscaped = $false; continue }
                        if ($char -eq '\') { $isEscaped = $true; continue }
                        if (($char -eq "'" -or $char -eq '"' -or $char -eq '`')) {
                            if ($inString -and $char -eq $stringChar) { $inString = $false } elseif (-not $inString) { $inString = $true; $stringChar = $char }
                        }
                        if ($inString) { continue }
                        if ($char -eq '(' -or $char -eq '{' -or $char -eq '[') { $depth++ }
                        elseif ($char -eq ')' -or $char -eq '}' -or $char -eq ']') { $depth-- }
                        if ($char -eq ',' -and $depth -eq 0) { ${first_comm-index} = $i; break }
                    }

                    if (${first_comm-index} -ne -1) {
                        $arg1 = $argsContent.Substring(0, ${first_comm-index}).Trim()
                        $rest = $argsContent.Substring(${first_comm-index} + 1).Trim()
                        $replacer = $rest
                        $restOfArgs = ''

                        # Find the second comma to isolate the replacer
                        $depth = 0; $inString = $false; $stringChar = ''; $isEscaped = $false; ${second_comm-index} = -1
                        for ($i = 0; $i -lt $rest.Length; $i++) {
                             $char = $rest[$i]
                             if ($isEscaped) { $isEscaped = $false; continue }
                             if ($char -eq '\') { $isEscaped = $true; continue }
                             if (($char -eq "'" -or $char -eq '"' -or $char -eq '`')) {
                                if ($inString -and $char -eq $stringChar) { $inString = $false } elseif (-not $inString) { $inString = $true; $stringChar = $char }
                             }
                             if ($inString) { continue }
                             if ($char -eq '(' -or $char -eq '{' -or $char -eq '[') { $depth++ }
                             elseif ($char -eq ')' -or $char -eq '}' -or $char -eq ']') { $depth-- }
                             if ($char -eq ',' -and $depth -eq 0) { ${second_comm-index} = $i; break }
                        }

                        if (${second_comm-index} -ne -1) {
                            $replacer = $rest.Substring(0, ${second_comm-index}).Trim()
                            $restOfArgs = $rest.Substring(${second_comm-index})
                        }

                        $wrappedReplacer = "(_k, v) => { let _r = ($replacer)(_k, v); return typeof _r === `"bigint`" ? _r.toString() : _r; }"
                        $newText = "JSON.stringify($arg1, $wrappedReplacer$restOfArgs)"
                        $newContent = $newContent.Remove($h.Position, $h.Text.Length).Insert($h.Position, $newText)
                    }
                }
            }
        }
        $content = $newContent
        Set-Content -Path $targetFile -Value $content -NoNewline -Encoding UTF8
        Write-Host "  Risky Bulk Patch Applied!" -ForegroundColor Green; Start-Sleep 2
    }
}
