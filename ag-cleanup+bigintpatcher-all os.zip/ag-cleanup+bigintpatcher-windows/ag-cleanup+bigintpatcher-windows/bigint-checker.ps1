# =====================================================================================
#  Antigravity BigInt Checker for Windows
# =====================================================================================

$targetFile = Join-Path $env:LOCALAPPDATA 'Programs\Antigravity\resources\app\out\main.js'
$logFile = "$PSScriptRoot\bigint-scan.log"

# --- Regex for DETECTION ---
$easyPatchRegex = 'JSON\.stringify\(([^,]*?),\s*\(_k, v\) => typeof v === "bigint" \? v\.toString\(\) : v\)'
$riskyWrappedUnpatchRegex = 'JSON\.stringify\((.*?),\s*\(_k, v\)\s*=>\s*{\s*let\s*_r\s*=\s*\((.*?)\)\(_k, v\);\s*return\s*typeof\s*_r\s*===\s*"bigint"\s*\?\s*_r\.toString\(\)\s*:\s*_r;\s*}(,.*?)?\)'
$riskyAddedUnpatchRegex = 'JSON\.stringify\(([\{\(\[].*?[\}\)\]]),\s*\(_k, v\) => typeof v === "bigint" \? v\.toString\(\) : v\)'

# --- Utility Functions ---
function Write-Header($title) {
    Clear-Host
    Write-Host ""
    Write-Host "  ==============================================================" -ForegroundColor Cyan
    Write-Host "             $title" -ForegroundColor Cyan
    Write-Host "  ==============================================================" -ForegroundColor Cyan
    Write-Host ""
}

# --- Main Application Loop ---
if (-not (Test-Path $targetFile)) { Write-Header "Error"; Write-Host "  Antigravity main.js not found at $targetFile" -ForegroundColor Red; exit }

while ($true) {
    Write-Header "Windows BigInt Checker"
    $content = Get-Content -Raw $targetFile

    # --- Analysis Phase ---
    $allRegex = 'JSON\.stringify\((?:[^()]|\([^()]*\))*\)'
    $allFoundMatches = [regex]::Matches($content, $allRegex)
    $allItems = @()
    $lineNumber = 1
    $currentPos = 0

    # This classification function must be IDENTICAL to the one in the patcher.
    function Get-Classification {
        param($text)
        if ($text -notmatch '^JSON\.stringify\((.*)\)$') { return @{ Type = 'unknown' } }
        $argsContent = $Matches[1].Trim()
        if ($argsContent -match '[\{\(\[\]\}\,]') { return @{ Type = 'risky' } } else { return @{ Type = 'easy' } }
    }

    foreach ($m in $allFoundMatches) {
        $text = $m.Value
        $index = $m.Index
        $gap = $content.Substring($currentPos, $index - $currentPos)
        $lineNumber += ($gap -split "`n").Length - 1
        $currentPos = $index
        
        $item = [PSCustomObject]@{ Line = $lineNumber; Position = $index; Text = $text; Type = ''; Color = 'Gray' }

        if ($text -like '*(typeof _r ===*bigint*)*') { # Check for the most specific patch first
            $item.Type = 'Patched (Risky-Wrapped)'; $item.Color = 'Cyan'
        } elseif ($text -like 'JSON.stringify(*, (_k, v) => typeof v === "bigint"*)') {
            # This is a broad check. We need to see if it was a risky-add or an easy-add.
            $unpatchedVersion = $text -replace ',\s*\(_k, v\) => typeof v === "bigint" \? v\.toString\(\) : v', ''
            $classification = Get-Classification -text $unpatchedVersion
            if ($classification.Type -eq 'easy') {
                $item.Type = 'Patched (Easy)'; $item.Color = 'Green'
            } else {
                $item.Type = 'Patched (Risky-Added)'; $item.Color = 'Yellow'
            }
        } else {
            $classification = Get-Classification -text $text
            if ($classification.Type -eq 'easy') {
                $item.Type = 'Unpatched (Easy)'; $item.Color = 'Red'
            } else {
                $item.Type = 'Unpatched (Risky)'; $item.Color = 'Yellow'
            }
        }
        $allItems += $item
    }

    # --- UI & Menu ---
    $patchedEasyCount = ($allItems | Where-Object { $_.Type -eq 'Patched (Easy)' }).Count
    $patchedRiskyAddedCount = ($allItems | Where-Object { $_.Type -eq 'Patched (Risky-Added)' }).Count
    $patchedRiskyWrappedCount = ($allItems | Where-Object { $_.Type -eq 'Patched (Risky-Wrapped)' }).Count
    $unpatchedEasyCount = ($allItems | Where-Object { $_.Type -eq 'Unpatched (Easy)' }).Count
    $unpatchedRiskyCount = ($allItems | Where-Object { $_.Type -eq 'Unpatched (Risky)' }).Count

    Write-Host "  Scan Complete!"
    Write-Host "  - Patched (Easy):          $patchedEasyCount" -ForegroundColor Green
    Write-Host "  - Patched (Risky-Added):   $patchedRiskyAddedCount" -ForegroundColor Yellow
    Write-Host "  - Patched (Risky-Wrapped): $patchedRiskyWrappedCount" -ForegroundColor Cyan
    Write-Host "  - Unpatched (Easy):        $unpatchedEasyCount" -ForegroundColor Red
    Write-Host "  - Unpatched (Risky):       $unpatchedRiskyCount" -ForegroundColor Yellow
    Write-Host ""
    
    Write-Host "  OPTIONS:" -ForegroundColor Gray
    Write-Host "  1. Show All items"
    Write-Host "  2. Show Patched items"
    Write-Host "  3. Show Unpatched items"
    Write-Host "  4. Save log and Exit"
    $choice = Read-Host "  Enter Option#"

    switch ($choice) {
        '1' {
            Write-Header "All JSON.stringify Calls ($($allItems.Count))"
            $allItems | ForEach-Object { Write-Host "  [L:$($_.Line)|P:$($_.Position)] $($_.Text)" -ForegroundColor $_.Color }
            Read-Host "`n  Press Enter to return to menu"
        }
        '2' {
            Write-Header "Patched Calls ($($patchedEasyCount + $patchedRiskyAddedCount + $patchedRiskyWrappedCount))"
            ($allItems | Where-Object { $_.Type -like 'Patched*' }) | ForEach-Object { Write-Host "  [L:$($_.Line)|P:$($_.Position)] $($_.Text)" -ForegroundColor $_.Color }
            Read-Host "`n  Press Enter to return to menu"
        }
        '3' {
            Write-Header "Unpatched Calls ($unpatchedCount)"
            ($allItems | Where-Object { $_.Type -eq 'Unpatched' }) | ForEach-Object { Write-Host "  [L:$($_.Line)|P:$($_.Position)] $($_.Text)" -ForegroundColor $_.Color }
            Read-Host "`n  Press Enter to return to menu"
        }
'''        '4' {
            $logContent = @()
            $logContent += "Antigravity BigInt Scan Results"
            $logContent += "================================================="
            $logContent += "Scan Date: $(Get-Date)"
            $logContent += "Target File: $targetFile"
            $logContent += ""
            $logContent += "Summary:"
            $logContent += "- Patched (Easy):          $patchedEasyCount"
            $logContent += "- Patched (Risky-Added):   $patchedRiskyAddedCount"
            $logContent += "- Patched (Risky-Wrapped): $patchedRiskyWrappedCount"
            $logContent += "- Unpatched (Easy):        $unpatchedEasyCount"
            $logContent += "- Unpatched (Risky):       $unpatchedRiskyCount"
            $logContent += ""
            $logContent += "Details:"
            $logContent += "================================================="
            $allItems | ForEach-Object {
                $logContent += "[L:$($_.Line)|P:$($_.Position)] [$($_.Type)] - $($_.Text)"
            }
            $logContent | Set-Content -Path $logFile -Encoding UTF8
            Write-Host "`n  Log saved to $logFile" -ForegroundColor Green
            Start-Sleep 2
            exit
        }'''}
    }
}
