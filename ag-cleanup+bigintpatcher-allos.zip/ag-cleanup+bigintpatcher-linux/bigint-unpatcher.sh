﻿#!/bin/bash

# =====================================================================================
#  Antigravity BigInt Unpatcher for Linux
# =====================================================================================

# --- Config ---
TARGET_FILE="$HOME/.config/Antigravity/app/out/main.js"
BACKUP_FILE="${TARGET_FILE}.bak"
PATCHED_BACKUP_FILE="${TARGET_FILE}.patched.bak"

# --- Regex for UNPATCHING ---
# These are perl-compatible regexes used for substitutions.
EASY_UNPATCH_REGEX='s/JSON\.stringify\(([^,]*?),\s*\(_k, v\) => typeof v === "bigint" \? v\.toString\(\) : v\)/JSON.stringify($1)/g'
RISKY_WRAPPED_UNPATCH_REGEX='s/JSON\.stringify\((.*?),\s*\(_k, v\)\s*=>\s*{\s*let\s*_r\s*=\s*\((.*?)\)\(_k, v\);\s*return\s*typeof\s*_r\s*===\s*"bigint"\s*\?\s*_r\.toString\(\)\s*:\s*_r;\s*}(,.*?)?\)/JSON.stringify($1, $2$3)/g'
RISKY_ADDED_UNPATCH_REGEX='s/JSON\.stringify\(([\{\(\[].*?[\}\)\]]),\s*\(_k, v\) => typeof v === "bigint" \? v\.toString\(\) : v\)/JSON.stringify($1)/g'

# --- Colors ---
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
GRAY='\033[0;90m'
NC='\033[0m' # No Color

# --- Utility Functions ---
write_header() {
    clear
    echo -e ""
    echo -e "${CYAN}  ==============================================================${NC}"
    echo -e "${CYAN}             $1${NC}"
    echo -e "${CYAN}  ==============================================================${NC}"
    echo -e ""
}

get_classification() {
    local text="$1"
    local args_content=$(echo "$text" | perl -nE 'say $1 if /^JSON\.stringify\((.*)\)$/')
    if echo "$args_content" | grep -q -P '[\{\(\[\]\}\,]'; then
        echo "risky"
    else
        echo "easy"
    fi
}

# --- Main Application Loop ---
if [[ ! -f "$TARGET_FILE" ]]; then
    # Fallback for some distributions that might use a different path
    TARGET_FILE="$HOME/snap/antigravity/current/.config/Antigravity/app/out/main.js"
    if [[ ! -f "$TARGET_FILE" ]]; then
        write_header "Error"
        echo -e "  ${RED}Antigravity main.js not found.${NC}"
        echo -e "  Checked standard paths. If you have a custom installation, please update the TARGET_FILE variable in this script."
        exit 1
    fi
fi

while true; do
    write_header "Linux BigInt Omni-Unpatcher"
    
    # --- Analysis Phase ---
    mapfile -t all_found_matches < <(perl -0777 -nE 'say for /JSON\.stringify\((?:[^()]|\([^()]*\))*\)/g' "$TARGET_FILE")

    patched_easy_count=0
    patched_risky_added_count=0
    patched_risky_wrapped_count=0
    unpatched_easy_count=0
    unpatched_risky_count=0

    for text in "${all_found_matches[@]}"; do
        if [[ "$text" == *'typeof _r === `"bigint"`'* ]]; then
            ((patched_risky_wrapped_count++))
        elif [[ "$text" == *'(_k, v) => typeof v === "bigint"'* ]]; then
            unpatched_version=$(echo "$text" | perl -pe 's/,\s*\(_k, v\) => typeof v === "bigint" \? v\.toString\(\) : v//g')
            classification=$(get_classification "$unpatched_version")
            if [[ "$classification" == "easy" ]]; then
                ((patched_easy_count++))
            else
                ((patched_risky_added_count++))
            fi
        else
            classification=$(get_classification "$text")
            if [[ "$classification" == "easy" ]]; then
                ((unpatched_easy_count++))
            else
                ((unpatched_risky_count++))
            fi
        fi
    done

    total_patched_count=$(($patched_easy_count + $patched_risky_added_count + $patched_risky_wrapped_count))

    # --- UI & Menu ---
    echo -e "  ${GREEN}File Scan Results:${NC}"
    echo -e "  - ${GREEN}Patched (Easy):          $patched_easy_count${NC}"
    echo -e "  - ${YELLOW}Patched (Risky-Added):   $patched_risky_added_count${NC}"
    echo -e "  - ${CYAN}Patched (Risky-Wrapped): $patched_risky_wrapped_count${NC}"
    echo -e "  - ${RED}Unpatched (Easy):        $unpatched_easy_count${NC}"
    echo -e "  - ${YELLOW}Unpatched (Risky):       $unpatched_risky_count${NC}"
    echo -e ""
    
    echo -e "  ${GRAY}OPTIONS:${NC}"
    echo -e "  1. Unpatch ALL ($total_patched_count found)"
    echo -e "  2. Unpatch Easy only ($patched_easy_count found)"
    echo -e "  3. Unpatch Risky-Added only ($patched_risky_added_count found)"
    echo -e "  4. Unpatch Risky-Wrapped only ($patched_risky_wrapped_count found)"
    echo -e "  5. Restore from backup ($BACKUP_FILE)"
    echo -e "  6. Exit"
    read -p "  Enter Option#: " choice

    case "$choice" in
        1) # UNPATCH ALL
            if [[ $total_patched_count -eq 0 ]]; then echo "  No patches to remove."; sleep 1; continue; fi
            echo -e "  ${YELLOW}Unpatching all found patches...${NC}"
            if [[ ! -f "$PATCHED_BACKUP_FILE" ]]; then cp "$TARGET_FILE" "$PATCHED_BACKUP_FILE"; fi
            
            # Use perl for in-place editing for safety and power.
            perl -i -0777pe "$RISKY_WRAPPED_UNPATCH_REGEX" "$TARGET_FILE"
            perl -i -0777pe "$RISKY_ADDED_UNPATCH_REGEX" "$TARGET_FILE"
            perl -i -0777pe "$EASY_UNPATCH_REGEX" "$TARGET_FILE"
            
            echo -e "  ${GREEN}Bulk Unpatch Applied!${NC}"; sleep 2
            ;;
        2) # UNPATCH EASY
            if [[ $patched_easy_count -eq 0 ]]; then echo "  No easy patches to remove."; sleep 1; continue; fi
            if [[ ! -f "$PATCHED_BACKUP_FILE" ]]; then cp "$TARGET_FILE" "$PATCHED_BACKUP_FILE"; fi
            perl -i -0777pe "$EASY_UNPATCH_REGEX" "$TARGET_FILE"
            echo -e "  ${GREEN}Easy patches removed!${NC}"; sleep 2
            ;;
        3) # UNPATCH RISKY-ADDED
            if [[ $patched_risky_added_count -eq 0 ]]; then echo "  No risky-added patches to remove."; sleep 1; continue; fi
            if [[ ! -f "$PATCHED_BACKUP_FILE" ]]; then cp "$TARGET_FILE" "$PATCHED_BACKUP_FILE"; fi
            perl -i -0777pe "$RISKY_ADDED_UNPATCH_REGEX" "$TARGET_FILE"
            echo -e "  ${GREEN}Risky-added patches removed!${NC}"; sleep 2
            ;;
        4) # UNPATCH RISKY-WRAPPED
            if [[ $patched_risky_wrapped_count -eq 0 ]]; then echo "  No risky-wrapped patches to remove."; sleep 1; continue; fi
            if [[ ! -f "$PATCHED_BACKUP_FILE" ]]; then cp "$TARGET_FILE" "$PATCHED_BACKUP_FILE"; fi
            perl -i -0777pe "$RISKY_WRAPPED_UNPATCH_REGEX" "$TARGET_FILE"
            echo -e "  ${GREEN}Risky-wrapped patches removed!${NC}"; sleep 2
            ;;
        5) # RESTORE BACKUP
            if [[ -f "$BACKUP_FILE" ]]; then
                echo -e "  ${YELLOW}Restoring original file from $BACKUP_FILE...${NC}"
                cp "$BACKUP_FILE" "$TARGET_FILE"
                echo -e "  ${GREEN}Restore complete!${NC}"
            else
                echo -e "  ${RED}Backup file not found ($BACKUP_FILE).${NC}"
            fi
            sleep 2
            ;;
        6) exit 0 ;;
    esac
done