@echo off
title Antigravity Omni Cleanup - Windows

echo  :: ============================================================================
echo  ::  Antigravity Omni Cleanup - Windows Launcher
echo  ::  Created by Duct thanks to research from the r/Google_Antigravity community.
echo  ::
echo  ::  This script runs the interactive omni cleanup for Antigravity.
echo  :: ============================================================================
pause

powershell -NoProfile -ExecutionPolicy Bypass -Command "& '%~dp0ag-omni-cleanup.ps1'"

echo.
pause
