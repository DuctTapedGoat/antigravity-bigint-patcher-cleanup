# =====================================================================================
#  Antigravity Omni Cleanup & Recovery Tool
# =====================================================================================

function Clear-HostWrite-Header {
    Clear-Host
    Write-Host ""
    Write-Host "  ============================================================" -ForegroundColor Cyan
    Write-Host "         Antigravity Omni Cleanup & Recovery Tool             " -ForegroundColor Cyan
    Write-Host "  ============================================================" -ForegroundColor Cyan
    Write-Host ""
}

$backupDir = Join-Path $env:USERPROFILE 'Antigravity_Backup'
$appDataPath = Join-Path $env:APPDATA 'Antigravity'
$localAppDataPath = Join-Path $env:LOCALAPPDATA 'Programs\Antigravity'
$geminiPath = Join-Path $env:USERPROFILE '.gemini'
$antiPath = Join-Path $env:USERPROFILE '.antigravity'

function Stop-Antigravity {
    $processName = "Antigravity"
    if (Get-Process $processName -ErrorAction SilentlyContinue) {
        Write-Host "  Zamykanie aplikacji Antigravity..." -ForegroundColor Yellow
        Stop-Process -Name $processName -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
    }
}

function New-Backup {
    Write-Host "  Tworzenie kopii zapasowej przed czyszczeniem..." -ForegroundColor Cyan
    if (-not (Test-Path $backupDir)) {
        New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
    }
    
    if (Test-Path $appDataPath) {
        Copy-Item -Path $appDataPath -Destination (Join-Path $backupDir 'AppData_Antigravity') -Recurse -Force
        Write-Host "    - Skopiowano AppData\Antigravity" -ForegroundColor Green
    }
    if (Test-Path $geminiPath) {
        Copy-Item -Path $geminiPath -Destination (Join-Path $backupDir '.gemini') -Recurse -Force
        Write-Host "    - Skopiowano .gemini" -ForegroundColor Green
    }
    if (Test-Path $antiPath) {
        Copy-Item -Path $antiPath -Destination (Join-Path $backupDir '.antigravity') -Recurse -Force
        Write-Host "    - Skopiowano .antigravity" -ForegroundColor Green
    }
    Write-Host "  Gotowe! Kopia zabezpieczona w: $backupDir" -ForegroundColor Green
}

function Invoke-Cleanup {
    param([bool]$hard)

    Stop-Antigravity
    New-Backup
    
    if ($hard) {
        Write-Host ""
        Write-Host "  Rozpoczynanie HARD CLEANUP (Twardy Reset)..." -ForegroundColor Red
    } else {
        Write-Host ""
        Write-Host "  Rozpoczynanie SOFT CLEANUP (Miekki Reset - zachowuje czaty)..." -ForegroundColor Yellow
    }
    
    $itemsToDelete = @()
    $itemsToDelete += $geminiPath
    $itemsToDelete += $antiPath
    
    if ($hard) {
        # Usuwa cala instalacje i caly AppData (z czatami)
        $itemsToDelete += $appDataPath
        $itemsToDelete += $localAppDataPath
    } else {
        # Miekki reset: Kasuje tylko Cache i Sesje
        if (Test-Path $appDataPath) {
            $itemsToDelete += Join-Path $appDataPath 'Cache'
            $itemsToDelete += Join-Path $appDataPath 'Code Cache'
            $itemsToDelete += Join-Path $appDataPath 'Network'
            $itemsToDelete += Join-Path $appDataPath 'Session Storage'
            $itemsToDelete += Join-Path $appDataPath 'Cookies'
            $itemsToDelete += Join-Path $appDataPath 'Cookies-journal'
            # Kasujemy GPU Cache, zeby bylo stabilnie
            $itemsToDelete += Join-Path $appDataPath 'GPUCache'
            $itemsToDelete += Join-Path $appDataPath 'DawnGraphiteCache'
            $itemsToDelete += Join-Path $appDataPath 'DawnWebGPUCache'
        }
    }

    foreach ($item in $itemsToDelete) {
        if (Test-Path $item) {
            try {
                Remove-Item -Path $item -Recurse -Force -ErrorAction Stop
                Write-Host "    - USUNIETO: $item" -ForegroundColor Green
            } catch {
                Write-Host "    - BLAD usuwania: $item" -ForegroundColor Red
            }
        }
    }
    
    Write-Host ""
    if ($hard) {
        Write-Host "  HARD CLEANUP Gotowy! Aplikacja zostala calkowicie wyczyszczona." -ForegroundColor Red
    } else {
        Write-Host "  SOFT CLEANUP Gotowy! Limity zresetowane, bazy danych SQLite (Czaty) zachowane." -ForegroundColor Green
    }
}

function Restore-Backup {
    if (-not (Test-Path $backupDir)) {
        Write-Host "  Brak folderu kopii zapasowej ($backupDir)!" -ForegroundColor Red
        return
    }
    
    Stop-Antigravity
    Write-Host ""
    Write-Host "  Przywracanie kopii zapasowej..." -ForegroundColor Cyan

    $bAppData = Join-Path $backupDir 'AppData_Antigravity'
    $bGemini = Join-Path $backupDir '.gemini'
    $bAnti = Join-Path $backupDir '.antigravity'

    if (Test-Path $bAppData) {
        if (Test-Path $appDataPath) { Remove-Item -Path $appDataPath -Recurse -Force }
        Copy-Item -Path $bAppData -Destination $appDataPath -Recurse -Force
        Write-Host "    - Przywrocono AppData\Antigravity" -ForegroundColor Green
    }
    if (Test-Path $bGemini) {
        if (Test-Path $geminiPath) { Remove-Item -Path $geminiPath -Recurse -Force }
        Copy-Item -Path $bGemini -Destination $geminiPath -Recurse -Force
        Write-Host "    - Przywrocono .gemini" -ForegroundColor Green
    }
    if (Test-Path $bAnti) {
        if (Test-Path $antiPath) { Remove-Item -Path $antiPath -Recurse -Force }
        Copy-Item -Path $bAnti -Destination $antiPath -Recurse -Force
        Write-Host "    - Przywrocono .antigravity" -ForegroundColor Green
    }
    
    Write-Host ""
    Write-Host "  Gotowe! Aplikacja zostala w pelni przywrocona." -ForegroundColor Green
}

while ($true) {
    Clear-HostWrite-Header
    Write-Host "  Opcje:"
    Write-Host "  1. SOFT CLEANUP (Resetuje limity/cache, zachowuje bazy danych SQLite z czatami)" -ForegroundColor Yellow
    Write-Host "  2. HARD CLEANUP (Twardy reset - usuwa wszystko, w tym czaty i pliki instalacyjne)" -ForegroundColor Red
    Write-Host "  3. RECOVERY     (Przywraca stary stan z ostatniej automatycznej kopii)" -ForegroundColor Green
    Write-Host "  4. Wyjscie"
    Write-Host ""
    
    $choice = Read-Host "  Wybierz opcje (1-4)"
    
    if ($choice -eq '1') {
        Invoke-Cleanup -hard $false
        Write-Host ""
        Read-Host "  Nacisnij Enter, aby powrocic do menu..."
    } elseif ($choice -eq '2') {
        Write-Host ""
        $sure = Read-Host "  UWAGA: Ta opcja skasuje Twoje czaty. Na pewno kontynuowac? (t/n)"
        if ($sure -eq 't') {
            Invoke-Cleanup -hard $true
        }
        Write-Host ""
        Read-Host "  Nacisnij Enter, aby powrocic do menu..."
    } elseif ($choice -eq '3') {
        Restore-Backup
        Write-Host ""
        Read-Host "  Nacisnij Enter, aby powrocic do menu..."
    } elseif ($choice -eq '4') {
        exit
    }
}
