'''#!/bin/bash
# This script ensures that the main shell script is executed when this .command file is double-clicked.
"$(dirname "$0")/ag-cleanup.sh"'''