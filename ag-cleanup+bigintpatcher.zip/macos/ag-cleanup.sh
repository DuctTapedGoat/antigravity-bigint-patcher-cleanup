'''#!/bin/bash

# =====================================================================================
#  Antigravity Cleanup Utility for macOS
# =====================================================================================

# --- Config ---
TARGET_DIR="$HOME/Library/Application Support/Antigravity/app/out"

# --- Colors ---
CYAN='\033[0;36m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# --- Main ---
clear
echo -e "${CYAN}Antigravity Cleanup Utility${NC}"
echo -e "This will remove backup files created by the patcher/unpatcher."
echo -e ""

if [ ! -d "$TARGET_DIR" ]; then
    echo -e "${RED}Target directory not found: $TARGET_DIR${NC}"
    exit 1
fi

BACKUP_FILE="$TARGET_DIR/main.js.bak"
PATCHED_BACKUP_FILE="$TARGET_DIR/main.js.patched.bak"

found=0

if [ -f "$BACKUP_FILE" ]; then
    echo -e "Found: $BACKUP_FILE"
    found=1
fi

if [ -f "$PATCHED_BACKUP_FILE" ]; then
    echo -e "Found: $PATCHED_BACKUP_FILE"
    found=1
fi

if [ $found -eq 0 ]; then
    echo -e "${GREEN}No backup files found to clean up.${NC}"
    exit 0
fi

echo -e ""
read -p "Proceed with deleting the file(s) listed above? (y/n): " choice

if [[ "$choice" == "y" || "$choice" == "Y" ]]; then
    if [ -f "$BACKUP_FILE" ]; then
        rm "$BACKUP_FILE"
        echo -e "Deleted: $BACKUP_FILE"
    fi
    if [ -f "$PATCHED_BACKUP_FILE" ]; then
        rm "$PATCHED_BACKUP_FILE"
        echo -e "Deleted: $PATCHED_BACKUP_FILE"
    fi
    echo -e "\n${GREEN}Cleanup complete!${NC}"
else
    echo -e "\nCleanup cancelled."
fi'''